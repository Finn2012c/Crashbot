const fs = require('fs')

global.owner = "62881038152952" //owner number
global.footer = "One Pice V9" //footer section
global.namabot = "One Pice V9" //nama bot
global.status = true //"self/public" section of the bot
global.namaowner = "Dapzy"
global.idsaluran = "-"
global.imgmenu = "https://daffa-dev.my.id/upload/rcqbk.jpg"

//======[ Setting Event ]======//
global.dana = `085885781051`
global.gopay = `085885791051`
global.ovo = "-"
global.shope = "-"
global.bank = "-"
global.qris = fs.readFileSync("./media/qris.jpg")
global.namastore = "`Dapazy Developer`"
global.lol = "";
global.msg = {
    owner: "You Are Not Owner",
    premium: "You Are Not Premium Member",
    admin: "You Are Not Admin",
    adminbot: "Me Not Admin",
    priv: "khusus pribadi",
    bot: "khusus nomer bot"
}
global.autoTyping = false // ubah jadi true untuk menyalakan auto typing

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
