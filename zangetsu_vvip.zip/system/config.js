//~~~~~~~~~ Setting Owner~~~~~~~~~~//
global.prefix = [".", "!", ".", ",", "🐤", "🗿"]; 
global.publik = true
global.owner = ["6285147315499"] 
global.namabot = 'itachi crahser'
//~~~~~~~~~ Setting ~~~~~~~~~~//
global.namach = "Informasi Bot & Website 2025"
global.link = "https://whatsapp.com/channel/0029Vb6jR6cHLHQYNx0h2P3e"
global.idch = "120363421332878757@newsletter"
global.imgthumb = "https://files.catbox.moe/te1u38.mp4"
global.vidthumb = "https://vt.tiktok.com/ZSPo9uXsq/"
//~~~~~~~~~ Setting Mess ~~~~~~~~~~//
global.mess = { 
owner: '𝖪𝗁𝗎𝗌𝗎𝗌 𝖮𝗐𝗇𝖾𝗋',
premium: '𝖪𝗁𝗎𝗌𝗎𝗌 𝖯𝗋𝖾𝗆𝗂𝗎𝗆',
succes: '𝖲𝗎𝖼𝖼𝖾𝗌𝗌𝖿𝗎𝗅'
//~~~~~~~~~ End ~~~~~~~~~~//
}