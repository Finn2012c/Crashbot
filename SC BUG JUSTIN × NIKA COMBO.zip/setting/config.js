const fs = require('fs')

//Bot Setting
global.owner = ['6288227981268'] //Own Number
global.urlfoto = 'https://img1.pixhost.to/images/8023/632424586_imgtmp.jpg' //Url Foto 
global.url = 'https://whatsapp.com/channel/0029VbBSG42KWEKsExp6gu2b' //Url Channel dev
global.developer = "sanzkece" //Dev Name
global.botname = "NIKITA" //Bot Name
global.version = "17.0.0" //Version Bot
global.footer = "Goo" //footer section
global.status = true //"self/public" section of the bot
global.autoreactDB = '120363404166660759' //Global auto react Channel 

//Sticker Setiings
global.packname = "Sticker By" //Pack Name 
global.author = "Theflash" // Author

global.lol = "";
global.mess = {
    owner: "𝐖𝐡𝐚𝐭𝐬?"
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
